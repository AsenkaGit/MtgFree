package asenka.mtgfree.model.exceptions;

/**
 * 
 * @author Asenka
 *
 */
@SuppressWarnings("serial")
public class MtgGameException extends Exception {

	/**
	 * 
	 * @param message
	 */
	public MtgGameException(String message) {

		super(message);
	}

}
